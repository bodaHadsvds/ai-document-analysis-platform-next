export interface DocumentItem {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  status: "idle" | "processing" | "completed" | "error";
  summary?: string;
  sentiment?: { label: string; score: number };
  entities?: { type: string; value: string }[];
  errorMessage?: string;
}

export interface DocumentProps {
  document: DocumentItem;
  onUpdateTitle: (id: string, newTitle: string) => void;
  onDelete: (id: string) => void;
   handleReanalyze: (id: string ,task:"summarization" | "sentiment" | "ner") => void; 
}
export interface StatusBadgeProps {
  status: 'idle' | 'processing' | 'completed' | 'error';
}

