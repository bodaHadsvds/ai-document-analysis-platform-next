"use client";

import { toast } from "sonner";
import { DocumentItem } from "../types/document";

export function useSSEAnalyzer(
  updateDocument: (
    id: string,
    updater: (current: DocumentItem) => DocumentItem
  ) => void
) {
  const analyzeDocument = async (doc: DocumentItem, task: "summarization" | "sentiment" | "ner") => {
    // Mark the doc as processing
    updateDocument(doc.id, (current) => ({
      ...current,
      status: "processing",
    }));

    try {
      const res = await fetch("/api/documents/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: doc.content, task }),
      });

      if (!res.body) throw new Error("No response body from SSE.");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop() || "";

        for (const part of parts) {
          if (!part.startsWith("data:")) continue;
          const jsonText = part.replace(/^data:\s*/, "");

          if (jsonText.trim() === "[DONE]") continue;

          try {
            const data = JSON.parse(jsonText);

            // 💡 handle generic streaming events
            switch (data.task) {
              // 🧠 Summarization
              case "summarization":
                if (data.chunk) {
                  updateDocument(doc.id, (current) => ({
                    ...current,
                    summary: (current.summary || "") + " " + data.chunk,
                  }));
                }
                if (data.done) {
                  updateDocument(doc.id, (current) => ({
                    ...current,
                    summary: data.result || current.summary,
                    status: "completed",
                  }));
                  toast.success(`🧠 "${doc.title}" summarized!`);
                }
                break;

              // 😊 Sentiment
           case "sentiment":
  if (data.done && data.result) {
    const { label, score } = data.result;
    let sentimentColor = "gray";
    let sentimentEmoji = "😐";

    // interpret label & score
    if (label === "POSITIVE" && score > 0.8) {
      sentimentColor = "green";
      sentimentEmoji = "😊";
    } else if (label === "NEGATIVE" && score > 0.8) {
      sentimentColor = "red";
      sentimentEmoji = "😡";
    } else {
      sentimentColor = "yellow";
      sentimentEmoji = "😐";
    }

    updateDocument(doc.id, (current) => ({
      ...current,
      sentiment: { label, score },
      status: "completed",
    }));

    toast.success(
      `${sentimentEmoji} ${label} (${(score * 100).toFixed(1)}%) for "${doc.title}"`,
      { style: { background: sentimentColor } }
    );
  }
  break;


              // 🏷️ Named Entity Recognition
              case "ner":
                if (data.entity) {
                  updateDocument(doc.id, (current) => ({
                    ...current,
                    entities: [
                      ...(current.entities || []),
                      data.entity,
                    ],
                  }));
                }
                if (data.done) {
                  updateDocument(doc.id, (current) => ({
                    ...current,
                    entities: data.result,
                    status: "completed",
                  }));
                  toast.success(`🏷️ Entities extracted for "${doc.title}"`);
                }
                break;

              default:
                if (data.status === "error") {
                  updateDocument(doc.id, (current) => ({
                    ...current,
                    status: "error",
                    errorMessage: data.message,
                  }));
                  toast.error(`❌ Error analyzing "${doc.title}"`);
                }
                break;
            }
          } catch {
            console.warn("⚠️ Bad SSE chunk:", jsonText);
          }
        }
      }
    } catch (err: any) {
      updateDocument(doc.id, (current) => ({
        ...current,
        status: "error",
        errorMessage: err.message,
      }));
      toast.error(`Error: ${err.message}`);
    }
  };

  return { analyzeDocument };
}
