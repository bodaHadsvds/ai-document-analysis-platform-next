"use client";

import { useState } from "react";
import { toast } from "sonner";
import { v4 as uuidv4 } from "uuid";
import { DocumentItem } from "../types/document";

export function useDocumentsState() {
const [documents, setDocuments] = useState<DocumentItem[]>([ { id: uuidv4(), title: "Short Sample", content: "This is a short document for testing summarization.", createdAt: new Date().toISOString(), status: "idle", }, { id: uuidv4(), title: "Medium Sample", content: "This medium-length document provides a balanced test for summarization speed and accuracy...", createdAt: new Date().toISOString(), status: "idle", }, { id: uuidv4(), title: "Long Sample", content: "This is a long sample document that contains multiple sentences, designed to test how the summarization model behaves with extended inputs...", createdAt: new Date().toISOString(), status: "idle", }, ]);

  const addDocument = (doc: DocumentItem) =>
    setDocuments((prev) => [doc, ...prev]);

  const deleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    toast.message("Document deleted.");
  };

const updateDocument = (
  id: string,
  updater: (current: DocumentItem) => DocumentItem
) => {
  setDocuments((prev) =>
    prev.map((d) => (d.id === id ? updater(d) : d))
  );
};

  return { documents, setDocuments, addDocument, deleteDocument, updateDocument };
}
