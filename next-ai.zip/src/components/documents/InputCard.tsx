import { Button } from "../ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card"
import { Textarea } from "../ui/textarea"
interface InputCardProps {
  error?: string
  newText: string
  setNewText: (value: string) => void
  setSelectedTask: (value: "summarization" | "sentiment" | "ner") => void
  handleAddText: () => void
  handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void
  uploading: boolean
  selectedTask:"summarization" | "sentiment" | "ner"
}
const  InputCard: React.FC<InputCardProps> = ({error ,setNewText ,selectedTask ,handleAddText ,newText,handleFileUpload ,uploading ,setSelectedTask}) => {
  const handleSelect =(task: "summarization" | "sentiment" | "ner")=>{
    setSelectedTask(task)
  }
  return (
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Submit Document</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter text here (max 5000 chars)..."
            value={newText}
            maxLength={5000}
            onChange={(e) => setNewText(e.target.value)}
 className="
    min-h-[120px] 
    bg-gray-100 text-gray-800 
    border border-gray-300 rounded-md p-2
    focus:outline-none focus:border-gray-300 focus:ring-0
    resize-none
  "

          />
          {error && <p className="text-sm text-red-500">{error}</p>}


   {/* 🧠 Task selector with radio buttons */}
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="task"
              value="summarization"
              checked={selectedTask === "summarization"}
              onChange={() => handleSelect("summarization")}
            />
            <span className="text-blue-600 font-medium">Summarization</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="task"
              value="sentiment"
              checked={selectedTask === "sentiment"}
              onChange={() => handleSelect("sentiment")}
            />
            <span className="text-green-600 font-medium">Sentiment</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="task"
              value="ner"
              checked={selectedTask === "ner"}
              onChange={() => handleSelect("ner")}
            />
            <span className="text-orange-600 font-medium">Entities</span>
          </label>
        </div>



          <div className="flex flex-col sm:flex-row gap-3">
            <Button onClick={handleAddText} className="w-full sm:w-auto">
              Analyze Text 
            </Button>
            <label className="w-full sm:w-auto cursor-pointer">
              <input
                type="file"
                accept=".txt"
                // className="hidden"
                onChange={handleFileUpload}
              />
         
              <Button variant="secondary" className="w-full sm:w-auto">
                {uploading ? 'Uploading...' : 'Upload .txt File'}
              </Button>
            </label>
          </div>
        </CardContent>
      </Card>
  )
}

export default InputCard