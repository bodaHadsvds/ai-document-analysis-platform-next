import { useState } from 'react';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';

import { Type, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

interface DocumentSubmissionProps {
  onSubmit: (content: string, filename?: string) => void;
}

export function DocumentSubmission({ onSubmit }: DocumentSubmissionProps) {
  const [textContent, setTextContent] = useState('');
  const [activeTab, setActiveTab] = useState('text');

  const handleTextSubmit = () => {
    if (!textContent.trim()) {
      toast.error('Please enter some text');
      return;
    }

    onSubmit(textContent);
    setTextContent('');
    toast.success('Document submitted for analysis');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Limit file size to 1MB
    if (file.size > 1024 * 1024) {
      toast.error('File size must be less than 1MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      onSubmit(content, file.name);
      toast.success('Document submitted for analysis');
      
      // Reset file input
      e.target.value = '';
    };
    reader.onerror = () => {
      toast.error('Error reading file');
    };
    reader.readAsText(file);
  };

  return (
    <Card className="p-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="text" className="flex items-center gap-2">
            <Type className="w-4 h-4" />
            Text Input
          </TabsTrigger>
          <TabsTrigger value="file" className="flex items-center gap-2">
            <Upload className="w-4 h-4" />
            File Upload
          </TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="space-y-4">
          <div>
            <Textarea
              placeholder="Enter your text here for AI analysis..."
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              className="min-h-[200px] resize-none"
            />
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-500">
              {textContent.trim().split(/\s+/).filter(Boolean).length} words
            </span>
            <Button onClick={handleTextSubmit}>Analyze Document</Button>
          </div>
        </TabsContent>

        <TabsContent value="file" className="space-y-4">
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-12 text-center hover:border-slate-400 transition-colors">
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".txt,.md,.json"
              onChange={handleFileUpload}
            />
            <label
              htmlFor="file-upload"
              className="cursor-pointer flex flex-col items-center gap-3"
            >
              <div className="p-4 bg-slate-100 rounded-full">
                <Upload className="w-8 h-8 text-slate-600" />
              </div>
              <div>
                <p className="text-slate-700 mb-1">
                  Click to upload or drag and drop
                </p>
                <p className="text-sm text-slate-500">
                  TXT, MD, or JSON files (max 1MB)
                </p>
              </div>
            </label>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}