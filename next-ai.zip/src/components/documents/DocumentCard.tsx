"use client";

import { DocumentProps } from "@/types/document";
import { useState } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import DocumentError from "./DocumentError";
import DocumentHeader from "./DocumentHeader";
import DocumentMeta from "./DocumentMetaData";
import DocumentProgress from "./DocumentProgress";
import DocumentSummary from "./DocumentSummary";

function DocumentCard({
  document,
  onUpdateTitle,
  onDelete,
  handleReanalyze,
}: DocumentProps) {
  const wordCount = document.content.trim().split(/\s+/).length;
  const [selectedTask, setSelectedTask] = useState<
    "summarization" | "sentiment" | "ner"
  >("summarization");

  // Pick colors dynamically for button
  const getButtonStyle = () => {
    switch (selectedTask) {
      case "summarization":
        return "bg-blue-600 hover:bg-blue-700 text-white";
      case "sentiment":
        return "bg-green-600 hover:bg-green-700 text-white";
      case "ner":
        return "bg-orange-600 hover:bg-orange-700 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  // Helper for sentiment display
  const renderSentiment = () => {
    if (!document.sentiment) return null;

    const { label, score } = document.sentiment;
    const confidence = (score * 100).toFixed(1);

    let color = "text-gray-600";
    let emoji = "😐";

    if (label === "POSITIVE" && score > 0.7) {
      color = "text-green-600";
      emoji = "😊";
    } else if (label === "NEGATIVE" && score > 0.7) {
      color = "text-red-600";
      emoji = "😡";
    } else {
      color = "text-yellow-600";
      emoji = "😐";
    }

    return (
      <div className={`text-sm font-medium ${color} flex items-center gap-1`}>
        <span>{emoji}</span>
        <span>
          Sentiment: {label} ({confidence}%)
        </span>
      </div>
    );
  };

  return (
    <Card className="p-6 hover:shadow-md transition-all group">
      <div className="space-y-4">
        {/* Header */}
        <DocumentHeader
          document={document}
          onUpdateTitle={onUpdateTitle}
          onDelete={onDelete}
        />

        {/* Metadata */}
        <DocumentMeta date={document.createdAt} wordCount={wordCount} />

        {/* Progress */}
        {document.status === "processing" && <DocumentProgress />}

        {/* Summary */}
        <DocumentSummary summary={document.summary} />
        {renderSentiment()}

        {document.entities && document.entities.length > 0 && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 space-y-2">
            <h4 className="font-semibold text-orange-700 text-sm">
              🏷️ Extracted Entities
            </h4>
            <div className="flex flex-wrap gap-2">
              {document.entities.map((e, i) => (
                <span
                  key={i}
                  className="px-2 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-medium"
                >
                  {e.value} <span className="text-gray-500">({e.type})</span>
                </span>
              ))}
            </div>
          </div>
        )}
        {document.status !== "processing" && (
          <div className="flex flex-col sm:flex-row items-center gap-3">
            {/* Task selector */}
            <select
              value={selectedTask}
              onChange={(e) =>
                setSelectedTask(
                  e.target.value as "summarization" | "sentiment" | "ner"
                )
              }
              className="border rounded-md px-2 py-1 text-sm"
            >
              <option value="summarization">🧠 Summarize</option>
              <option value="sentiment">😊 Sentiment</option>
              <option value="ner">🏷️ Entities</option>
            </select>

            <Button
              size="sm"
              onClick={() => handleReanalyze(document.id, selectedTask)}
              className={getButtonStyle()}
            >
              Re-analyze ({selectedTask})
            </Button>
          </div>
        )}
        {/* Error */}
        {document.status === "error" && (
          <DocumentError message={document.errorMessage} />
        )}
      </div>
    </Card>
  );
}
export default DocumentCard;
