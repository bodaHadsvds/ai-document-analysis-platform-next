'use client';

import DocumentCard from './DocumentCard';
import NoDocument from './NoDocument';

interface Document {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  status: 'idle' | 'processing' | 'completed' | 'error';
  summary?: string;
  sentiment?: { label: string; score: number };
  entities?: { type: string; value: string }[];
}

interface DocumentListProps {
  documents: Document[];
  onUpdateTitle: (id: string, newTitle: string) => void;
  onDelete: (id: string) => void;
   handleReanalyze: (id: string ,task:"summarization" | "sentiment" | "ner") => void; 
}

export function DocumentList({ documents, onUpdateTitle, onDelete ,handleReanalyze}: DocumentListProps) {
  if (documents.length === 0) return <NoDocument />;

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3 text-slate-800">
        Documents ({documents.length})
      </h2>
      <div className="space-y-4">
        {documents.map((doc) => (
          <DocumentCard
            key={doc.id}
            document={doc}
            onUpdateTitle={onUpdateTitle}
            onDelete={onDelete}
            handleReanalyze={handleReanalyze}
          />
        ))}
      </div>
    </div>
  );
}
