"use client";

import { DocumentList } from "@/components/documents/DocumentList";
import InputCard from "@/components/documents/InputCard";
import BlueParticlesBackground from "@/components/particlesbg";
import { useDocumentAnalyzer } from "@/hooks/useDocumentAnalyzer";
export default function HomePage() {
    const {
    documents,
    newText,
    error,
    uploading,
    setNewText,
    handleAddText,
    handleFileUpload,
    handleReanalyze,
    handleDelete,
    handleUpdateTitle,
     selectedTask,
  setSelectedTask
  } = useDocumentAnalyzer();

  return (
    <div className="min-h-screen  p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">
    AI Document Analysis Platform
      </h1>
<BlueParticlesBackground />
      {/* Input Card */}
      <InputCard
        error={error}
        setNewText={setNewText}
        handleAddText={handleAddText}
        newText={newText}
        handleFileUpload={handleFileUpload}
        uploading={uploading}
        setSelectedTask={setSelectedTask}
        selectedTask={selectedTask}
      />

      {/* Documents List */}
      <DocumentList
        documents={documents}
        onUpdateTitle={handleUpdateTitle}
        onDelete={handleDelete}
        handleReanalyze={handleReanalyze}
   
      />
    </div>
  );
}
