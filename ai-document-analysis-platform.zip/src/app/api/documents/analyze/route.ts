import { NextRequest } from "next/server";

interface SSEMessage {
  status: "processing" | "completed" | "error";
  message?: string;
  result?: any;
}

export async function POST(request: NextRequest) {
  const { content } = await request.json();

  if (!content || content.trim().length === 0) {
    return new Response("Missing content", { status: 400 });
  }

  // إنشاء Stream
  const stream = new ReadableStream({
    async start(controller) {
      try {
        const encoder = new TextEncoder();

        // 🔹 1. أرسل أول حدث: بدأ التحليل
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ status: "processing", message: "بدأ التحليل..." })}\n\n`)
        );

        // 🔹 2. استدعاء موديل التلخيص
        const response = await fetch(
          "https://router.huggingface.co/hf-inference/models/facebook/bart-large-cnn",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${process.env.HUGGINGFACE_API_TOKEN}`,
            },
            body: JSON.stringify({ inputs: content }),
          }
        );

        if (!response.ok) {
          const errorText = await response.text();
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ status: "error", message: errorText })}\n\n`)
          );
          controller.close();
          return;
        }

        const data = await response.json();

        // 🔹 3. أرسل النتيجة النهائية
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({
              status: "completed",
              message: "تم التحليل بنجاح ",
              result: data[0],
            })}\n\n`
          )
        );
      } catch (error: any) {
        controller.enqueue(
          new TextEncoder().encode(
            `data: ${JSON.stringify({ status: "error", message: error.message })}\n\n`
          )
        );
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
