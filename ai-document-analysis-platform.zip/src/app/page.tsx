"use client";
import { useState } from "react";

export default function Home() {
  const [messages, setMessages] = useState<any[]>([]);

  const testStream = async () => {
    const res = await fetch("/api/documents/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: "Testing SSE stream from React" }),
    });

    if (!res.body) return console.error("No response body!");

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const parts = buffer.split("\n\n");
      for (const part of parts) {
        if (part.startsWith("data:")) {
          const json = JSON.parse(part.replace("data: ", ""));
          setMessages((prev) => [...prev, json]);
          console.log("Event:", json);
        }
      }
    }
  };

  return (
    <div className="min-h-screen p-8">
      <h1 className="text-2xl font-bold mb-4">hello from nextjs ai</h1>

      <button
        onClick={testStream}
        className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
      >
        Start SSE Stream
      </button>

      <div className="mt-4 space-y-2">
        {messages.map((msg, i) => (
          <div key={i} className="border p-2 rounded bg-gray-100">
            <strong>{msg.status}</strong>: {msg.message || JSON.stringify(msg.result)}
          </div>
        ))}
      </div>
    </div>
  );
}
